import './style.css';
import 'leaflet/dist/leaflet.css';

import React, { useState } from 'react';
import { MapContainer, TileLayer, GeoJSON } from 'react-leaflet';
import { Popup } from 'react-leaflet';

import PopUpCompoent from './PopupComponent';
import geojsonData from './data.json';

function MapContainerComponent() {
  const geojsonStyle = {
    fillColor: 'red',
    color: 'black', // Boundary color
    weight: 2, // Boundary line thickness
    opacity: 1,
  };
  // Function to handle mouse hover (mouseover) event
  const handleMouseOver = (e) => {
    const layer = e.target;
    layer.setStyle({
      fillColor: 'blue', // Change fill color on hover
    });
  };

  // Function to handle mouse out (mouseout) event
  const handleMouseOut = (e) => {
    const layer = e.target;
    layer.setStyle({
      fillColor: 'transparent', // Restore fill color on mouseout
    });
  };

  const [popup, setPopup] = useState(null);
  const [countyName, setCountyName] = useState('');
  // Function to handle click event
  const handleClick = (e) => {
    console.log('Clicked element::::', e.target.feature.properties.NAME);
    setCountyName(e.target.feature.properties.NAME);
    setPopup(e.latlng);
    //e.target.bindPopup(popupContent).openPopup();
  };
  return (
    <MapContainer center={[37.839333, -85.27002]} zoom={8}>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <GeoJSON
        data={geojsonData}
        style={geojsonStyle}
        onEachFeature={(feature, layer) => {
          // Bind the mouse hover and click event handlers
          layer.on({
            mouseover: handleMouseOver,
            mouseout: handleMouseOut,
            click: handleClick,
          });
        }}
      />
      {popup && (
        <Popup position={popup}>
          <PopUpCompoent name={countyName} />
        </Popup>
      )}
    </MapContainer>
  );
}

export default MapContainerComponent;
