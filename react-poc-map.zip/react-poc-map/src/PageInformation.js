import React from "react";

function PageInformationComponent() {
  return (
    <div>
      <h1>Media Gallery</h1>
      <h2>Images</h2>
      <img src="image1.jpg" alt="photos for the county" />
      <img src="image2.jpg" alt="photos for the county" />
      <h2>Videos</h2>
      <video controls>
        <source src="video1.mp4" type="video/mp4" />
      </video>
      <video controls>
        <source src="video2.mp4" type="video/mp4" />
      </video>
    </div>
  );
}

export default PageInformationComponent;
