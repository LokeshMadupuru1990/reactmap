import React from "react";
import { Link } from "react-router-dom"; // Import Link from React Router

function PopUpComponent({ name }) {
  return (
    <div>
      <p>
        County Name:&nbsp;{name}
        <br />
        <a href="/page2" target="_blank">
          Click here{" "}
        </a>{" "}
        to view information
      </p>
      <Link to="/media" target="_blank">
        Click here to view media
      </Link>
    </div>
  );
}

export default PopUpComponent;
